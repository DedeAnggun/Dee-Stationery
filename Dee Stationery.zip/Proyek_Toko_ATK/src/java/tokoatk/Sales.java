package tokoatk;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class Sales {
    public String id;
    public LocalDateTime waktu;
    public String username;

    
    public LocalDateTime getWaktu() {
        return waktu;
    }
    
    public String getId() {
        return id;
    }
    
    public String getUsername() {
        return username;
    }
    public String getWaktuFormatted() {
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
    return waktu.format(formatter);
}

    
        public boolean baca(String id) {
            Connection conn = null;
            PreparedStatement st;
            ResultSet rs;

            try {
                conn = DbConnection.connect();

                String sql = "SELECT * from salesm where id=?";
                st = conn.prepareStatement(sql);
                st.setString(1, id);
                rs = st.executeQuery();

                boolean result = rs.next();
                this.id = rs.getString("id");
                this.username = rs.getString("username");

                // tambahkan ini agar waktu terbaca
                java.sql.Timestamp waktuSql = rs.getTimestamp("waktu");
                if (waktuSql != null) {
                    this.waktu = waktuSql.toLocalDateTime();
                }

                conn.close();
                return result;
            } catch (Exception ex) {
                ex.printStackTrace(); 
                return false;
            }
        }

        public boolean tambah(String username) {
           Connection conn = null;
           PreparedStatement st;

           try {
               conn = DbConnection.connect();

               LocalDateTime dt = LocalDateTime.now();
               DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyMMddHHmmssS");
               id = dt.format(formatter);

               // waktu harus di-convert jadi Timestamp untuk MySQL
               java.sql.Timestamp waktuSql = java.sql.Timestamp.valueOf(dt);
               this.waktu = dt; 

               String sql = "INSERT INTO salesm (id, username, waktu) values (?, ?, ?)";
               st = conn.prepareStatement(sql);
               st.setString(1, id);
               st.setString(2, username);
               st.setTimestamp(3, waktuSql); 
               st.executeUpdate();

               conn.close();
               return true;

           } catch (Exception ex) {
               ex.printStackTrace(); 
               return false;
           }
       }

    
    public boolean hapus() {
        Connection conn = null;
        PreparedStatement st;

        try {
            conn = DbConnection.connect();

            // Hapus dulu semua detail dari transaksi ini
            String sqlDetail = "DELETE FROM salesd WHERE salesId=?";
            st = conn.prepareStatement(sqlDetail);
            st.setString(1, id);
            st.executeUpdate();

            //Baru hapus header-nya dari salesm
            String sql = "DELETE FROM salesm WHERE id=?";
            st = conn.prepareStatement(sql);
            st.setString(1, id);
            st.executeUpdate();

            conn.close();
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }

    

    public boolean addDetail(String barangId, Integer qty, Integer harga) {
        SalesDetail detail = new SalesDetail();
        detail.salesId = this.id;
        detail.barangId = barangId;
        detail.qty = qty;
        detail.harga = harga;
        return detail.tambah();
    }
    

    
    public ArrayList<SalesDetail> getDetail() {
        Connection conn = null;
        PreparedStatement st;
        ResultSet rs;
        ArrayList<SalesDetail> result = new ArrayList<>();

        try {
            conn = DbConnection.connect();

            // prepare select statement
            String sql = "SELECT * from salesd where salesId=?";
            st = conn.prepareStatement(sql);
            st.setString(1, this.id);
            rs = st.executeQuery();

            while(rs.next()) {
        SalesDetail entry = new SalesDetail();
        entry.baca(rs.getInt("id"));
        result.add(entry);
    }
            conn.close();

            return result;
        } catch (Exception ex) {
            return null;
        }
    }
    
    public static ArrayList<Sales> getList() {
        Connection conn = null;
        PreparedStatement st;
        ResultSet rs;
        ArrayList<Sales> result = new ArrayList<Sales>();

        try {
            conn = DbConnection.connect();

            // prepare select statement
            String sql = "SELECT * from salesm";
            st = conn.prepareStatement(sql);
            rs = st.executeQuery();

            while(rs.next()) {
                Sales entry = new Sales();
                entry.baca(rs.getString("id"));
                result.add(entry);
            }
            conn.close();

            return result;
        } catch (Exception ex) {
            return null;
        }
    }
    public static int getHariIni() {
    try {
        Connection conn = DbConnection.connect();
        String sql = "SELECT COUNT(*) FROM salesm WHERE DATE(waktu) = CURDATE()";
        PreparedStatement st = conn.prepareStatement(sql);
        ResultSet rs = st.executeQuery();

        if (rs.next()) return rs.getInt(1);

        conn.close();
    } catch (Exception ex) {
        ex.printStackTrace();
    }
    return 0;
}

}