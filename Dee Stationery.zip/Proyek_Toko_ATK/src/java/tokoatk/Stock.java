package tokoatk;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class Stock {
    public String id;
    public LocalDateTime waktu;
    public String username;
    public ArrayList<StockDetail> detail = new ArrayList<>();

    public String getId() { 
        return id; 
    }
    public String getUsername() { 
        return username; 
    }
    public LocalDateTime getWaktu() { 
        return waktu; 
    }

    public String getWaktuFormatted() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        return waktu.format(formatter);
    }
    
    

    public boolean baca(String id) {
        try (Connection conn = DbConnection.connect()) {
            String sql = "SELECT * FROM stockm WHERE id=?";
            PreparedStatement st = conn.prepareStatement(sql);
            st.setString(1, id);
            ResultSet rs = st.executeQuery();

            if (rs.next()) {
                this.id = rs.getString("id");
                this.username = rs.getString("username");
                Timestamp ts = rs.getTimestamp("waktu");
                if (ts != null) {
                    this.waktu = ts.toLocalDateTime();
                }
                this.detail = getDetail();

                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

   public boolean hapus() {
        Connection conn = null;
        PreparedStatement st;

        try {
            conn = DbConnection.connect();

            // Hapus dulu semua detail dari transaksi ini
            String sqlDetail = "DELETE FROM stockd WHERE stockId=?";
            st = conn.prepareStatement(sqlDetail);
            st.setString(1, id);
            st.executeUpdate();

            //Baru hapus header-nya dari salesm
            String sql = "DELETE FROM stockm WHERE id=?";
            st = conn.prepareStatement(sql);
            st.setString(1, id);
            st.executeUpdate();

            conn.close();
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }
   
    public boolean tambah(String username) {
        try (Connection conn = DbConnection.connect()) {
            LocalDateTime dt = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyMMddHHmmssS");
            id = dt.format(formatter);
            Timestamp waktuSql = Timestamp.valueOf(dt);

            String sql = "INSERT INTO stockm (id, username, waktu) VALUES (?, ?, ?)";
            PreparedStatement st = conn.prepareStatement(sql);
            st.setString(1, id);
            st.setString(2, username);
            st.setTimestamp(3, waktuSql);
            st.executeUpdate();
            this.waktu = dt;
            
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean addDetail(String barangId, int qty, int harga) {
        StockDetail detail = new StockDetail();
        detail.stockId = this.id;
        detail.barangId = barangId;
        detail.qty = qty;
        detail.harga = harga;
        return detail.tambah();
    }

    public ArrayList<StockDetail> getDetail() {
        ArrayList<StockDetail> result = new ArrayList<>();
        try (Connection conn = DbConnection.connect()) {
            String sql = "SELECT * FROM stockd WHERE stockId=?";
            PreparedStatement st = conn.prepareStatement(sql);
            st.setString(1, this.id);
            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                StockDetail d = new StockDetail();
                d.baca(rs.getInt("id"));
                result.add(d);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    public static ArrayList<Stock> getList() {
        ArrayList<Stock> list = new ArrayList<>();
        try (Connection conn = DbConnection.connect()) {
            String sql = "SELECT * FROM stockm ORDER BY waktu DESC";
            PreparedStatement st = conn.prepareStatement(sql);
            ResultSet rs = st.executeQuery();

            while (rs.next()) {
                Stock s = new Stock();
                s.baca(rs.getString("id"));
                list.add(s);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
