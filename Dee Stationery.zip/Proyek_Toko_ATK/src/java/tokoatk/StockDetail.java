package tokoatk;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class StockDetail {
    public Integer id;
    public String stockId;
    public String barangId;
    public Integer qty;
    public Integer harga;

    public Integer getId() {
        return id;
    }

    public String getStockId() {
        return stockId;
    }

    public String getBarangId() {
        return barangId;
    }

    public Integer getQty() {
        return qty;
    }

    public Integer getHarga() {
        return harga;
    }

    public Integer getTotal() {
        return harga * qty;
    }

//    public String getBarangNama() {
//        Barang barang = new Barang();
//        barang.baca(barangId);
//        return barang.getNama();
//    }
    public String barangNama;

        public String getBarangNama() {
            if (barangNama == null) {
                Barang barang = new Barang();
                barang.baca(barangId);
                barangNama = barang.getNama();
            }
            return barangNama;
        }


    public boolean tambah() {
    Connection conn = null;
    PreparedStatement st;

    try {
        conn = DbConnection.connect();

        String sql = "INSERT INTO stockd (stockId, barangId, qty, harga) VALUES (?, ?, ?, ?)";
        st = conn.prepareStatement(sql);
        st.setString(1, stockId);
        st.setString(2, barangId);
        st.setInt(3, qty);
        st.setInt(4, harga);
        st.executeUpdate();
        conn.close();

        System.out.println("Detail stok berhasil ditambahkan, barangId: " + barangId);

        // Tambah stok barang
        Barang b = new Barang();
        if (b.baca(barangId)) {
            System.out.println("Sebelum tambah stok: " + b.getStock());
            b.setStock(b.getStock() + qty);
            b.update();
            System.out.println("Sesudah tambah stok: " + b.getStock());
        } else {
            System.out.println("Gagal membaca data barang: " + barangId);
        }

        return true;
    } catch (Exception ex) {
        ex.printStackTrace();
        return false;
    }
}


    public boolean baca(Integer id) {
        Connection conn = null;
        PreparedStatement st;
        ResultSet rs;

        try {
            conn = DbConnection.connect();
            String sql = "SELECT * FROM stockd WHERE id=?";
            st = conn.prepareStatement(sql);
            st.setInt(1, id);
            rs = st.executeQuery();

            boolean result = rs.next();
            this.id = id;
            this.stockId = rs.getString("stockId");
            this.barangId = rs.getString("barangId");
            this.qty = rs.getInt("qty");
            this.harga = rs.getInt("harga");

            conn.close();
            return result;
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }

    public boolean hapus() {
        Connection conn = null;
        PreparedStatement st;

        try {
            conn = DbConnection.connect();
            String sql = "DELETE FROM stockd WHERE id=?";
            st = conn.prepareStatement(sql);
            st.setInt(1, id);
            st.executeUpdate();
            conn.close();

            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }
    public boolean updateQty() {
    try (Connection conn = DbConnection.connect()) {
        String sql = "UPDATE stockd SET qty=? WHERE id=?";
        PreparedStatement st = conn.prepareStatement(sql);
        st.setInt(1, this.qty);
        st.setInt(2, this.id);
        st.executeUpdate();
        return true;
    } catch (Exception e) {
        e.printStackTrace();
        return false;
    }
}

}
